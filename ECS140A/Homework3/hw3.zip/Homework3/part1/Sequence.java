public class Sequence{

}
