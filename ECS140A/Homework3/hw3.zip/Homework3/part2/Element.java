abstract public class Element{
	 abstract public void Print(); //the printing abstract method
}
